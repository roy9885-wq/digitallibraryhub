/**
 * Fuente dinámica de la Biblioteca Digital.
 *
 * En la versión React de la aplicación, este módulo sustituye al antiguo
 * script.js: consulta la API pública de Apps Script y devuelve los registros
 * tipados para que la interfaz pueda renderizarlos sin manipular el DOM.
 */

export const SHEET_API_URL =
  'https://script.google.com/macros/s/AKfycbzDxfJe5c_kdqB0WD2XB4C7-yBJOYVBBM0eAzSHavx73ob_I-96EfJJjNG42JUBTQ80/exec';

export type SheetText = {
  id: string;
  sa: string;
  titulo: string;
  meta: string;
  contexto: string;
  fragmento: string;
  pdfUrl: string;
};

function isSheetText(value: unknown): value is SheetText {
  if (!value || typeof value !== 'object') return false;

  const row = value as Record<string, unknown>;
  return ['id', 'sa', 'titulo', 'meta', 'contexto', 'fragmento'].every(
    (field) => typeof row[field] === 'string' && row[field],
  ) && (typeof row.pdfUrl === 'string' || typeof row.pdfUrl === 'undefined');
}

export async function fetchTexts(signal?: AbortSignal): Promise<SheetText[]> {
  const response = await fetch(SHEET_API_URL, {
    signal,
    headers: { Accept: 'application/json' },
  });

  if (!response.ok) {
    throw new Error(`La hoja de cálculo respondió con ${response.status}.`);
  }

  const payload: unknown = await response.json();

  if (!Array.isArray(payload)) {
    throw new Error('La hoja de cálculo no devolvió una lista de textos.');
  }

  const rows = payload.filter(isSheetText).map((row) => ({
    ...row,
    pdfUrl: row.pdfUrl ?? '',
  }));

  if (rows.length === 0) {
    throw new Error('La hoja de cálculo no contiene textos válidos.');
  }

  return rows;
}