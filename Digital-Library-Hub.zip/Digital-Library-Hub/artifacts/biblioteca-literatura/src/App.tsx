import { type ReactNode, useEffect, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { BookMarked, BookOpen, ChevronDown, FileText, Library, Search, X } from 'lucide-react';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { fetchTexts, SHEET_API_URL, type SheetText } from './script';

type Reading = {
  title: string;
  meta: string;
  context: string;
  textTitle: string;
  excerpt: string;
  pdfUrl: string;
};

type Author = { key: string; name: string; reading?: Reading };
type Situation = { id: string; number: string; title: string; question: string; authors: Author[] };

const readings: Record<string, Reading> = {
  'enuma-elish': {
    title: 'Enuma Elish',
    meta: 'Mesopotamia · Poema de la Creación',
    context: "El 'Enuma Elish' es el poema mesopotámico sobre el origen del mundo y los dioses, redactado en tablillas de arcilla hacia el siglo XVII a. C.",
    textTitle: 'Tablilla I · El caos primigenio',
    excerpt: 'Cuando en lo alto el cielo no tenía nombre, / ni abajo la tierra firme había sido llamada, / nada existía salvo el primordial Apsu, su progenitor, / y la matriz Tiamat, que a todos engendró...',
    pdfUrl: '#',
  },
  gilgamesh: {
    title: 'Epopeya de Gilgamesh',
    meta: 'Mesopotamia · Siglo XVIII a. C.',
    context: 'Considerada la obra narrativa más antigua de la humanidad, narra la búsqueda obsesiva de la inmortalidad tras la muerte de Enkidu.',
    textTitle: 'Tablilla XI · El encuentro con Utnapishtim',
    excerpt: "Gilgamesh le dijo a Utnapishtim: 'Te miro y eres como yo, no eres más grande... Dime, ¿cómo entraste en la asamblea de los dioses para buscar la vida eterna?'",
    pdfUrl: '#',
  },
  hesiodo: {
    title: 'Hesíodo',
    meta: 'Grecia · Siglo VIII a. C.',
    context: 'En la Teogonía, Hesíodo recopila y ordena los mitos sobre el origen de los dioses y la creación del cosmos a partir del Caos.',
    textTitle: 'Teogonía · El origen del Universo',
    excerpt: 'En primer lugar existió el Caos. Después la Tierra de ancho pecho, sede firme de todos los Inmortales... y Eros, el más hermoso entre los dioses.',
    pdfUrl: '#',
  },
  ovidio: {
    title: 'Ovidio',
    meta: "Roma · 'Metamorfosis' (8 d. C.)",
    context: 'Poema mitológico en quince libros que narra la historia del mundo desde su creación hasta la deificación de Julio César a través de las transformaciones.',
    textTitle: 'Apolo y Dafne',
    excerpt: "Cansada la virgen por el esfuerzo del escape, palidece y mirando a las aguas del Peneas dice: 'Ayúdame, padre; si los ríos tenéis poder divino, destruye esta figura por la que he gustado demasiado'...",
    pdfUrl: '#',
  },
  borges: {
    title: 'Jorge Luis Borges',
    meta: "Argentina · 'El Aleph' (1949)",
    context: "Maestro de la reescritura contemporánea de los mitos clásicos a través de la perspectiva del supuesto 'monstruo'.",
    textTitle: 'La casa de Asterión',
    excerpt: 'Sé que me acusan de soberbia, y tal vez de misantropía, y tal vez de locura. ' +
      'Tales acusaciones (que yo castigaré a su debido tiempo) son irrisorias. ' +
      'Es verdad que no salgo de mi casa, pero también es verdad que sus puertas están abiertas día y noche...',
    pdfUrl: '#',
  },
};

const situations: Situation[] = [
  {
    id: 'sa1',
    number: '01',
    title: 'El Mito',
    question: 'Cuando el mundo todavía estaba por nombrar.',
    authors: [
      { key: 'enuma-elish', name: 'Enuma Elish', reading: readings['enuma-elish'] },
      { key: 'gilgamesh', name: 'Epopeya de Gilgamesh', reading: readings.gilgamesh },
      { key: 'hesiodo', name: 'Hesíodo', reading: readings.hesiodo },
      { key: 'ovidio', name: 'Ovidio', reading: readings.ovidio },
      { key: 'borges', name: 'J. L. Borges', reading: readings.borges },
    ],
  },
  {
    id: 'sa2',
    number: '02',
    title: 'El Héroe',
    question: 'Una figura que vuelve distinta después del viaje.',
    authors: ['Homero', 'Beowulf', 'Cervantes', 'James Joyce'].map((name) => ({ key: name.toLowerCase().replaceAll(' ', '-'), name })),
  },
  {
    id: 'sa3',
    number: '03',
    title: 'El Teatro',
    question: 'La palabra se vuelve cuerpo frente a otros.',
    authors: ['Sófocles', 'Shakespeare', 'Molière', 'Yasmina Reza'].map((name) => ({ key: name.toLowerCase().replaceAll(' ', '-'), name })),
  },
  {
    id: 'sa4',
    number: '04',
    title: 'La Poesía',
    question: 'Nombrar lo que todavía no tiene forma.',
    authors: ['Enheduanna', 'Safo', 'Rimbaud'].map((name) => ({ key: name.toLowerCase(), name })),
  },
  {
    id: 'sa5',
    number: '05',
    title: 'La Memoria',
    question: 'Lo que queda cuando el tiempo ha pasado.',
    authors: ['San Agustín', 'Montaigne', 'Ana Frank'].map((name) => ({ key: name.toLowerCase().replaceAll(' ', '-'), name })),
  },
  {
    id: 'sa6',
    number: '06',
    title: 'El Otro',
    question: 'Mirar de frente a quien no somos.',
    authors: ['Luciano de Samosata', 'Jonathan Swift', 'Mary Shelley'].map((name) => ({ key: name.toLowerCase().replaceAll(' ', '-'), name })),
  },
];

const allAuthors = situations.flatMap((situation) => situation.authors);
const availableCount = allAuthors.filter((author) => author.reading).length;

function mergeSheetTexts(rows: SheetText[]): Situation[] {
  return situations.map((situation) => ({
    ...situation,
    authors: rows
      .filter((row) => row.sa === situation.id)
      .map((row) => ({
        key: row.id,
        name: row.titulo,
        reading: {
          title: row.titulo,
          meta: row.meta,
          context: row.contexto,
          textTitle: row.titulo,
          excerpt: row.fragmento,
          pdfUrl: row.pdfUrl,
        },
      })),
  }));
}

function Home() {
  const [activeSituation, setActiveSituation] = useState('sa1');
  const [selectedKey, setSelectedKey] = useState('enuma-elish');
  const [query, setQuery] = useState('');
  const [remoteSituations, setRemoteSituations] = useState<Situation[]>([]);
  const [libraryStatus, setLibraryStatus] = useState<'loading' | 'ready' | 'error'>('loading');

  const librarySituations = remoteSituations.length > 0 ? remoteSituations : situations;
  const libraryAuthors = librarySituations.flatMap((situation) => situation.authors);
  const libraryAvailableCount = libraryAuthors.filter((author) => author.reading).length;
  const selectedAuthor = libraryAuthors.find((author) => author.key === selectedKey) ?? libraryAuthors[0] ?? allAuthors[0];
  const normalizedQuery = query.trim().toLocaleLowerCase('es');
  const filteredSituations = useMemo(() => {
    if (!normalizedQuery) return librarySituations;
    return librarySituations.map((situation) => ({
      ...situation,
      authors: situation.authors.filter((author) => {
        const haystack = [situation.title, situation.question, author.name, author.reading?.title, author.reading?.meta, author.reading?.context, author.reading?.excerpt].filter(Boolean).join(' ').toLocaleLowerCase('es');
        return haystack.includes(normalizedQuery);
      }),
    })).filter((situation) => situation.authors.length > 0 || situation.title.toLocaleLowerCase('es').includes(normalizedQuery));
  }, [librarySituations, normalizedQuery]);

  useEffect(() => {
    const controller = new AbortController();

    fetchTexts(controller.signal)
      .then((rows) => {
        const nextSituations = mergeSheetTexts(rows);
        setRemoteSituations(nextSituations);
        setSelectedKey(rows[0]?.id ?? '');
        setActiveSituation(rows[0]?.sa ?? 'sa1');
        setLibraryStatus('ready');
      })
      .catch((error: unknown) => {
        if (controller.signal.aborted) return;
        console.error('Error al conectar con Google Sheets:', error);
        setLibraryStatus('error');
      });

    return () => controller.abort();
  }, []);

  const chooseAuthor = (situationId: string, authorKey: string) => {
    setActiveSituation(situationId);
    setSelectedKey(authorKey);
    document.getElementById('lector')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <div className="paper-noise min-h-[100dvh] bg-background">
      <header className="sticky top-0 z-10 border-b border-[hsl(var(--sidebar-border))] bg-[hsl(var(--sidebar))] text-[hsl(var(--sidebar-foreground))]">
        <div className="mx-auto flex max-w-[1440px] items-center justify-between px-5 py-4 lg:px-10">
          <a href="#inicio" className="group flex items-center gap-3" data-testid="link-home">
            <span className="flex h-9 w-9 items-center justify-center border border-[hsl(var(--sidebar-primary)/.5)] bg-[hsl(var(--sidebar-primary)/.12)] text-[hsl(var(--sidebar-primary))] transition-transform group-hover:-rotate-6">
              <Library size={18} strokeWidth={1.8} />
            </span>
            <span className="hidden text-sm font-semibold tracking-[.02em] sm:block">Literatura Universal</span>
            <span className="border-l border-[hsl(var(--sidebar-border))] pl-3 text-xs tracking-[.18em] text-[hsl(var(--sidebar-foreground)/.56)]">4.º ESO</span>
          </a>
          <nav className="flex items-center gap-5 text-xs font-semibold tracking-[.08em] text-[hsl(var(--sidebar-foreground)/.7)]" aria-label="Navegación principal">
            <a className="transition-colors hover:text-[hsl(var(--sidebar-primary))]" href="#inicio" data-testid="link-inicio">Inicio</a>
            <a className="transition-colors hover:text-[hsl(var(--sidebar-primary))]" href="#repositorio" data-testid="link-repositorio">Situaciones de aprendizaje</a>
          </nav>
        </div>
      </header>

      <main id="inicio">
        <section className="ink-grid relative overflow-hidden bg-[hsl(var(--sidebar))] px-5 py-16 text-[hsl(var(--sidebar-foreground))] md:py-24 lg:px-10">
          <div className="hero-circle hero-circle--outer pointer-events-none absolute -right-24 -top-36 h-[27rem] w-[27rem] rounded-full border md:-right-12 md:-top-48" aria-hidden="true" />
          <div className="hero-circle hero-circle--middle pointer-events-none absolute -right-3 top-12 hidden h-72 w-72 rounded-full border border-dashed lg:block" aria-hidden="true" />
          <div className="hero-circle hero-circle--small pointer-events-none absolute right-[18%] top-[28%] hidden h-40 w-40 rounded-full border lg:block" aria-hidden="true" />
          <div className="relative mx-auto grid max-w-[1440px] items-end gap-12 lg:grid-cols-[minmax(0,1fr)_310px]">
            <div className="max-w-4xl">
              <div className="animate-in mb-7 flex items-center gap-3 text-xs font-semibold uppercase tracking-[.18em] text-[hsl(var(--sidebar-primary))]">
                <span className="h-px w-8 bg-[hsl(var(--sidebar-primary))]" /> Repositorio digital · Departamento de Lengua
              </div>
              <h1 className="animate-in delay-1 serif max-w-4xl text-5xl leading-[.98] tracking-[-.035em] text-[hsl(var(--sidebar-foreground))] sm:text-7xl lg:text-[6.7rem]">
                Leer el mundo <em className="font-normal text-[hsl(var(--sidebar-primary))]">antes</em> de explicarlo.
              </h1>
              <p className="animate-in delay-2 mt-8 max-w-2xl text-base leading-7 text-[hsl(var(--sidebar-foreground)/.7)] sm:text-lg">
                Repositorio Digital de Literatura Universal. Lecturas, contextos y textos fundamentales del patrimonio literario universal para 4.º de ESO.
              </p>
              <a href="#repositorio" className="animate-in delay-3 mt-9 inline-flex items-center gap-3 border border-[hsl(var(--sidebar-primary)/.5)] bg-[hsl(var(--sidebar-primary))] px-5 py-3 text-sm font-bold text-[hsl(var(--sidebar-primary-foreground))] transition-all hover:-translate-y-0.5 hover:bg-[hsl(var(--sidebar-primary)/.88)]" data-testid="link-explorar">
                Entrar en la colección <BookOpen size={16} />
              </a>
            </div>
            <div className="animate-in delay-4 border-l border-[hsl(var(--sidebar-border))] pl-6 lg:mb-2">
              <p className="text-xs uppercase tracking-[.2em] text-[hsl(var(--sidebar-foreground)/.5)]">Una biblioteca para</p>
              <p className="serif mt-3 text-3xl leading-tight text-[hsl(var(--sidebar-foreground))]">hacer preguntas<br />que duran.</p>
            </div>
          </div>
        </section>

        <section className="border-b border-[hsl(var(--border))] bg-[hsl(var(--card))] px-5 py-5 lg:px-10">
          <div className="mx-auto grid max-w-[1440px] grid-cols-2 gap-5 md:grid-cols-4">
            <Stat value="06" label="situaciones de aprendizaje" />
            <Stat value={String(libraryAuthors.length).padStart(2, '0')} label="autores en el recorrido" />
            <Stat value={String(libraryAvailableCount).padStart(2, '0')} label="lecturas disponibles" />
            <Stat value="∞" label="preguntas por descubrir" />
          </div>
        </section>

        <section id="repositorio" className="mx-auto max-w-[1440px] scroll-mt-20 px-5 py-12 lg:px-10 lg:py-16">
          <div className="mb-9 flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <div>
              <p className="text-xs font-bold uppercase tracking-[.2em] text-[hsl(var(--secondary))]">El archivo</p>
              <h2 className="serif mt-2 text-4xl tracking-[-.025em] text-[hsl(var(--primary))] md:text-5xl">Seis formas de entrar a la literatura.</h2>
              <p className="mt-3 max-w-xl text-sm leading-6 text-[hsl(var(--muted-foreground))]">Elige una situación, sigue una voz y deja que el fragmento abra la conversación.</p>
            </div>
            <label className="relative block w-full md:w-80">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[hsl(var(--muted-foreground))]" size={17} />
              <input value={query} onChange={(event) => setQuery(event.target.value)} type="search" placeholder="Buscar en autores y lecturas" className="h-11 w-full border border-[hsl(var(--border))] bg-[hsl(var(--card))] pl-10 pr-10 text-sm outline-none transition-colors placeholder:text-[hsl(var(--muted-foreground)/.7)] focus:border-[hsl(var(--secondary))] focus:ring-2 focus:ring-[hsl(var(--secondary)/.2)]" data-testid="input-search" />
              {query && <button type="button" onClick={() => setQuery('')} className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--primary))]" aria-label="Limpiar búsqueda" data-testid="button-clear-search"><X size={16} /></button>}
            </label>
          </div>

          <div className="grid items-start gap-7 lg:grid-cols-[300px_minmax(0,1fr)]">
            <aside className="border border-[hsl(var(--border))] bg-[hsl(var(--card))] p-3 shadow-[var(--shadow-paper)]" aria-label="Situaciones de aprendizaje">
              <div className="flex items-center justify-between border-b border-[hsl(var(--border))] px-3 pb-3">
                <span className="text-xs font-bold uppercase tracking-[.17em] text-[hsl(var(--muted-foreground))]">Índice de sala</span>
                <BookMarked size={16} className="text-[hsl(var(--secondary))]" />
              </div>
              <div className="mt-3 space-y-1">
                {filteredSituations.map((situation) => {
                  const isOpen = situation.id === activeSituation;
                  return <div key={situation.id} className="border-b border-[hsl(var(--border)/.65)] last:border-0">
                    <button type="button" onClick={() => setActiveSituation(isOpen ? '' : situation.id)} className={`flex w-full items-start justify-between gap-2 px-3 py-3 text-left transition-colors ${isOpen ? 'bg-[hsl(var(--accent))]' : 'hover:bg-[hsl(var(--muted)/.65)]'}`} aria-expanded={isOpen} data-testid={`button-accordion-${situation.id}`}>
                      <span><span className={`mr-2 font-mono text-[10px] ${isOpen ? 'text-[hsl(var(--secondary))]' : 'text-[hsl(var(--muted-foreground))]'}`}>{situation.number}</span><span className="text-sm font-bold text-[hsl(var(--primary))]">{situation.title}</span></span>
                      <ChevronDown size={16} className={`mt-0.5 shrink-0 text-[hsl(var(--muted-foreground))] transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                    </button>
                    {isOpen && <div className="animate-in space-y-0.5 px-2 pb-2 pt-1">
                      {situation.authors.map((author) => <button type="button" key={author.key} onClick={() => chooseAuthor(situation.id, author.key)} className={`group flex w-full items-center justify-between px-3 py-2 text-left text-sm transition-colors ${selectedKey === author.key ? 'font-bold text-[hsl(var(--secondary-foreground))]' : 'text-[hsl(var(--muted-foreground))] hover:text-[hsl(var(--primary))]'}`} data-testid={`button-author-${author.key}`}>
                        <span className="flex items-center gap-2"><span className={`h-1.5 w-1.5 rounded-full ${selectedKey === author.key ? 'bg-[hsl(var(--secondary))]' : 'bg-[hsl(var(--border))] group-hover:bg-[hsl(var(--secondary))]'}`} />{author.name}</span>
                        {author.reading && <span className="text-[10px] uppercase tracking-wider text-[hsl(var(--secondary))]">texto</span>}
                      </button>)}
                      {situation.authors.length === 0 && <p className="px-3 py-3 text-xs italic text-[hsl(var(--muted-foreground))]">No hay coincidencias en esta sala.</p>}
                    </div>}
                  </div>;
                })}
                {filteredSituations.length === 0 && <div className="px-3 py-8 text-center"><Search className="mx-auto text-[hsl(var(--muted-foreground))]" size={20} /><p className="mt-3 text-sm text-[hsl(var(--muted-foreground))]">No encontramos esa entrada.</p></div>}
              </div>
            </aside>

            <article id="lector" className="scroll-mt-24 min-h-[480px] border border-[hsl(var(--border))] bg-[hsl(var(--card))] shadow-[var(--shadow-paper)]" data-testid="panel-reader">
              <div className="border-b border-[hsl(var(--border))] bg-[hsl(var(--muted)/.42)] px-6 py-4 sm:px-10">
                <div className="flex items-center justify-between gap-4">
                  <p className="text-xs font-bold uppercase tracking-[.18em] text-[hsl(var(--muted-foreground))]">Ficha de lectura</p>
                  <span className="flex items-center gap-2 text-xs text-[hsl(var(--muted-foreground))]"><span className={`h-2 w-2 rounded-full ${libraryStatus === 'error' ? 'bg-[hsl(var(--destructive))]' : 'bg-[hsl(var(--secondary))]'}`} />{libraryStatus === 'loading' ? 'Sincronizando colección' : libraryStatus === 'error' ? 'Fuente no disponible · mostrando archivo local' : selectedAuthor.reading ? 'Material disponible' : 'Material pendiente'}</span>
                </div>
              </div>
              {selectedAuthor.reading ? <ReadingCard reading={selectedAuthor.reading} /> : <EmptyReading author={selectedAuthor.name} />}
            </article>
          </div>
        </section>

      </main>
      <footer className="bg-[hsl(var(--sidebar))] px-5 py-8 text-[hsl(var(--sidebar-foreground)/.62)] lg:px-10">
        <div className="mx-auto flex max-w-[1440px] flex-col justify-between gap-3 text-xs sm:flex-row sm:items-center">
           <p>Biblioteca Digital de Literatura Universal · Roy Páramo de Llano</p>
          <div className="flex flex-wrap items-center gap-4">
            <a href={SHEET_API_URL} target="_blank" rel="noreferrer" className="text-[hsl(var(--sidebar-primary))] underline-offset-4 transition-colors hover:text-[hsl(var(--sidebar-foreground))] hover:underline">Fuente de datos</a>
            <p className="text-[hsl(var(--sidebar-primary))]">Una colección para volver.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function Stat({ value, label }: { value: string; label: string }) {
  return <div className="flex items-baseline gap-3 border-l-2 border-[hsl(var(--secondary)/.55)] pl-3"><strong className="serif text-3xl font-medium text-[hsl(var(--primary))]">{value}</strong><span className="max-w-[120px] text-[10px] font-bold uppercase leading-4 tracking-[.12em] text-[hsl(var(--muted-foreground))]">{label}</span></div>;
}

function ReadingCard({ reading }: { reading: Reading }) {
  const hasPdf = isUsablePdfUrl(reading.pdfUrl);
  return <div className="animate-in px-6 py-9 sm:px-10 sm:py-12">
    <p className="text-xs font-bold uppercase tracking-[.19em] text-[hsl(var(--secondary-foreground))]">{reading.meta}</p>
    <h2 className="serif mt-3 text-4xl leading-[1.05] tracking-[-.03em] text-[hsl(var(--primary))] sm:text-6xl">{reading.title}</h2>
    <div className="mt-8 border-l-2 border-[hsl(var(--secondary))] bg-[hsl(var(--accent)/.52)] px-5 py-4 sm:px-6">
      <p className="text-[10px] font-bold uppercase tracking-[.18em] text-[hsl(var(--secondary-foreground)/.75)]">Contexto</p>
      <p className="mt-2 text-sm leading-6 text-[hsl(var(--foreground))]">{reading.context}</p>
    </div>
    <div className="mt-10 max-w-3xl">
      <div className="mb-3 flex items-center gap-3"><span className="h-px w-7 bg-[hsl(var(--secondary))]" /><p className="text-xs font-bold uppercase tracking-[.18em] text-[hsl(var(--muted-foreground))]">Fragmento seleccionado</p></div>
      <h3 className="serif text-2xl text-[hsl(var(--primary))] sm:text-3xl">{reading.textTitle}</h3>
      <blockquote className="serif mt-5 whitespace-pre-line border-b border-[hsl(var(--border))] pb-8 text-xl leading-[1.65] text-[hsl(var(--foreground)/.83)] sm:text-2xl">“{reading.excerpt}”</blockquote>
    </div>
    <div className="mt-8 flex flex-wrap items-center gap-4">
      {hasPdf ? <a href={reading.pdfUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 bg-[hsl(var(--secondary))] px-4 py-3 text-sm font-bold text-[hsl(var(--secondary-foreground))] transition-transform hover:-translate-y-0.5" data-testid={`link-pdf-${reading.title}`}><FileText size={16} /> Ver PDF completo</a> : <span className="inline-flex items-center gap-2 border border-dashed border-[hsl(var(--border))] px-4 py-3 text-xs font-semibold text-[hsl(var(--muted-foreground))]" data-testid={`status-pdf-pending-${reading.title}`}><FileText size={16} /> PDF pendiente de enlace</span>}
    </div>
  </div>;
}

function isUsablePdfUrl(url: string) {
  if (!url || url === '#' || url.includes('...')) return false;

  try {
    const parsed = new URL(url);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:';
  } catch {
    return false;
  }
}

function EmptyReading({ author }: { author: string }) {
  return <div className="flex min-h-[430px] items-center justify-center px-8 py-12 text-center">
    <div className="max-w-sm animate-in">
      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-[hsl(var(--secondary)/.5)] bg-[hsl(var(--accent)/.5)] text-[hsl(var(--secondary-foreground))]"><BookOpen size={25} strokeWidth={1.5} /></div>
      <p className="mt-6 text-xs font-bold uppercase tracking-[.18em] text-[hsl(var(--secondary-foreground))]">Próxima incorporación</p>
      <h2 className="serif mt-3 text-4xl text-[hsl(var(--primary))]">{author}</h2>
      <p className="mt-4 text-sm leading-6 text-[hsl(var(--muted-foreground))]">Todavía no hay una ficha de lectura para esta entrada. El material de esta sección se publicará próximamente.</p>
      <span className="mt-7 inline-flex items-center gap-2 border border-[hsl(var(--border))] px-4 py-2 text-xs text-[hsl(var(--muted-foreground))]"><BookMarked size={14} /> Material pendiente</span>
    </div>
  </div>;
}

function Router() {
  return <RoutedErrorBoundary><Switch><Route path="/" component={Home} /><Route component={NotFound} /></Switch></RoutedErrorBoundary>;
}

function NotFound() {
  return <main className="flex min-h-[100dvh] items-center justify-center bg-background p-6 text-center"><div><Library className="mx-auto text-[hsl(var(--secondary))]" size={32} /><h1 className="serif mt-4 text-4xl text-[hsl(var(--primary))]">Página no encontrada</h1><a className="mt-5 inline-block text-sm font-bold text-[hsl(var(--secondary-foreground))] underline" href="/">Volver a la biblioteca</a></div></main>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

const queryClient = new QueryClient();

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;